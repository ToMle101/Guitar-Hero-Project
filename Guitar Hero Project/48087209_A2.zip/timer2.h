/*
 * timer2.h
 *
 * Author: Peter Sutton
 *
 * timer 2 skeleton
 */

#ifndef TIMER2_H_
#define TIMER2_H_

#include <stdint.h>

/* Set up our timer 
 */
void init_timer2(void);


#endif /* TIMER2_H_ */
